#!/bin/bash

/opt/wildfly/bin/standalone.sh -b 0.0.0.0 &
cd /opt/ejbca-ce
ant -q clean deployear