#!/bin/bash

wildfly_check() {
  DURATION_SECONDS=30
  if [ ! -z "$1" ]; then
    DURATION_SECONDS="$1"
  fi
  DURATION=$(echo "$DURATION_SECONDS / 5" | bc)

  echo "wait ${DURATION_SECONDS}s for start up wildfly"
  for i in `seq 1 $DURATION`; do
    /opt/wildfly/bin/jboss-cli.sh --connect ":read-attribute(name=server-state)" | grep "result" | awk '{ print $3; }'|grep running
    if [ $? -eq 0 ]; then
      return 0
    fi
    sleep 5
  done
  echo "wildfly not started after ${DURATION_SECONDS}s, exit"
  exit 1
}

ejbca_deploy_check() {
  DURATION_SECONDS=30
  if [ ! -z "$1" ]; then
    DURATION_SECONDS="$1"
  fi
  DURATION=$(echo "$DURATION_SECONDS / 5" | bc)

  echo "wait ${DURATION_SECONDS}s for deploying EJBCA"
  for i in `seq 1 $DURATION`; do
    if [ -f /opt/wildfly/standalone/deployments/ejbca.ear.deployed ]; then
      echo "EJBCA deployed"
      return 0
    fi
    sleep 5
  done
  echo "EJBCA not deployed after ${DURATION_SECONDS}s, exit"
  exit 1
}

/opt/wildfly/bin/standalone.sh -b 0.0.0.0 &
wildfly_check
cd /opt/ejbca-ce
ant -q clean deployear
/opt/wildfly/bin/jboss-cli.sh --connect :reload
ejbca_deploy_check
