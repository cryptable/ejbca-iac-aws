#!/bin/bash

docker cp $1:/opt/primekey/ejbca/conf/certstore.properties .
docker cp $1:/opt/primekey/ejbca/conf/cesecore.properties .
docker cp $1:/opt/primekey/ejbca/conf/crlstore.properties .
docker cp $1:/opt/primekey/ejbca/conf/database.properties .
docker cp $1:/opt/primekey/ejbca/conf/databaseprotection.properties .
docker cp $1:/opt/primekey/ejbca/conf/ejbca.properties .
docker cp $1:/opt/primekey/ejbca/conf/jaxws.properties .
docker cp $1:/opt/primekey/ejbca/conf/maintenance.properties .
docker cp $1:/opt/primekey/ejbca/conf/ocsp.properties . 
docker cp $1:/opt/primekey/ejbca/conf/web.properties .
