#!/bin/bash

docker cp $1:/opt/ejbca-ce/conf/batchtool.properties.sample .
docker cp $1:/opt/ejbca-ce/conf/cache.properties.sample .
docker cp $1:/opt/ejbca-ce/conf/catoken.properties.sample .
docker cp $1:/opt/ejbca-ce/conf/cesecore.properties.sample .
docker cp $1:/opt/ejbca-ce/conf/custom.properties.sample .
docker cp $1:/opt/ejbca-ce/conf/database.properties.sample .
docker cp $1:/opt/ejbca-ce/conf/ejbca.properties.sample .
docker cp $1:/opt/ejbca-ce/conf/externalra.properties.sample .
docker cp $1:/opt/ejbca-ce/conf/install.properties.sample .
docker cp $1:/opt/ejbca-ce/conf/jaxws.properties.sample .
docker cp $1:/opt/ejbca-ce/conf/mail.properties.sample .
docker cp $1:/opt/ejbca-ce/conf/ocsp.properties.sample . 
docker cp $1:/opt/ejbca-ce/conf/scepra.properties.sample .
docker cp $1:/opt/ejbca-ce/conf/systemtests.properties.sample .
docker cp $1:/opt/ejbca-ce/conf/va-publisher.properties.sample .
docker cp $1:/opt/ejbca-ce/conf/va.properties.sample .
docker cp $1:/opt/ejbca-ce/conf/web.properties.sample .
