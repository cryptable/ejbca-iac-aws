#!/bin/bash

docker cp $1:/opt/ejbca-ce/dist/ejbca.ear .